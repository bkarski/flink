package com.example;

import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.tuple.Tuple5;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;

import java.util.Properties;

public class FlinkExampleProcessor {
    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment env =
                StreamExecutionEnvironment.getExecutionEnvironment();

        Properties kafkaProperties = new Properties();

        kafkaProperties.setProperty(
                "bootstrap.servers",
                "localhost:19092,localhost:29092, localhost:39092"
        );
        kafkaProperties.setProperty(
                "group.id",
                "FLINK"
        );

        FlinkKafkaConsumer010<String> kafkaConsumer = new FlinkKafkaConsumer010(
                    "bus",
                new SimpleStringSchema(),
                kafkaProperties
        );

        DataStream<String> kafkaSource = env.addSource(kafkaConsumer);

        DataStream<String> parsedKaskaSource = kafkaSource.flatMap(
                (s, collector) -> {
                    String[] tablica = s.split(",");
                    String type = tablica[0].split(":")[1];
                    String line = tablica[1].split(":")[1];
                    String brigade = tablica[2].split(":")[1];
                    String latitude = tablica[3].split(":")[1];
                    String longitude = tablica[4].split(":")[1];

                Tuple5<String, String, String, String, String> t =
                        new Tuple5(type, line, brigade, latitude, longitude);


                    collector.collect(t);
                }
        );

        parsedKaskaSource.print();

        env.execute("PW Big Data");
    }
}
